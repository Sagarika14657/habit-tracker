import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import LoginScreen from './screens/LoginScreen';
import HomeScreen from './screens/HomeScreen';
import HabitScreen from './screens/habitScreen';
import { HabitProvider } from './screens/HabitContext';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <HabitProvider>
      <NavigationContainer>
        <Stack.Navigator
          initialRouteName="Login"
          screenOptions={{
            headerStyle: { backgroundColor: '#294C59' },
            headerTintColor: '#fff',
          }}
        >
          <Stack.Screen name="Login" component={LoginScreen} />
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen name="Habits" component={HabitScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </HabitProvider>
  );
}