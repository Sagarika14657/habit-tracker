import React, { createContext, useState } from 'react';

export const HabitContext = createContext();

export const HabitProvider = ({ children }) => {
  const [habits, setHabits] = useState([]);

  const addHabit = (name) => {
    const newHabit = {
      id: Date.now().toString(),
      name,
      streak: 0,
      lastCompleted: null,
    };
    setHabits([newHabit, ...habits]);
  };

  const markComplete = (id) => {
    const today = new Date().toDateString();

    setHabits((prev) =>
      prev.map((habit) => {
        if (habit.id === id) {
          if (habit.lastCompleted === today) return habit;

          const yesterday = new Date();
          yesterday.setDate(yesterday.getDate() - 1);

          const isStreak =
            habit.lastCompleted === yesterday.toDateString();

          return {
            ...habit,
            streak: isStreak ? habit.streak + 1 : 1,
            lastCompleted: today,
          };
        }
        return habit;
      })
    );
  };

  return (
    <HabitContext.Provider value={{ habits, addHabit, markComplete }}>
      {children}
    </HabitContext.Provider>
  );
};