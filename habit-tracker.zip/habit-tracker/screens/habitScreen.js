import React, { useContext, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from 'react-native';
import { HabitContext } from '../screens/HabitContext';

export default function HabitScreen() {
  const { habits, addHabit, markComplete } = useContext(HabitContext);
  const [newHabit, setNewHabit] = useState('');

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Your Habits</Text>

      <TextInput
        placeholder="Add new habit..."
        placeholderTextColor="#aaa"
        style={styles.input}
        value={newHabit}
        onChangeText={setNewHabit}
      />

      <TouchableOpacity
        style={styles.addButton}
        onPress={() => {
          if (!newHabit.trim()) return;
          addHabit(newHabit);
          setNewHabit('');
        }}
      >
        <Text style={styles.buttonText}>Add Habit</Text>
      </TouchableOpacity>

      <FlatList
        data={habits}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.habitText}>{item.name}</Text>

            <View style={styles.streakBadge}>
              <Text style={styles.streakText}>
                🔥 {item.streak} day streak
              </Text>
            </View>

            <TouchableOpacity
              style={styles.completeButton}
              onPress={() => markComplete(item.id)}
            >
              <Text style={styles.completeText}>Mark Complete</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#294C59',
    padding: 20,
  },
  title: {
    fontSize: 26,
    color: '#fff',
    marginBottom: 15,
  },
  input: {
    backgroundColor: '#ECC99C',
    padding: 12,
    borderRadius: 10,
    marginBottom: 10,
    color: '#1a1a1a',
  },
  addButton: {
    backgroundColor: '#C87A4A',
    padding: 12,
    borderRadius: 10,
    marginBottom: 20,
  },
  card: {
    backgroundColor: '#ECC99C',
    padding: 15,
    borderRadius: 12,
    marginBottom: 12,
  },
  habitText: {
    color: '#1a1a1a',
    fontWeight: 'bold',
    fontSize: 16,
  },
  streakBadge: {
    backgroundColor: '#A1CEC5',
    padding: 6,
    borderRadius: 8,
    marginTop: 6,
    alignSelf: 'flex-start',
  },
  streakText: {
    color: '#294C59',
  },
  completeButton: {
    backgroundColor: '#803828',
    padding: 10,
    borderRadius: 8,
    marginTop: 10,
  },
  completeText: {
    color: '#fff',
    textAlign: 'center',
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
  },
});